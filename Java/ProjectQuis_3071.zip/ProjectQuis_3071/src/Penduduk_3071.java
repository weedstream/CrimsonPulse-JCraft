public class Penduduk_3071 {
  protected String nik_3071;
  protected String nama_3071;
  protected int umur_3071;
  protected String alamat_3071;

  public void tampilDataPenduduk_3071 () {
    // this.nama_3071 = nama_3071;
    // this.nik_3071 = nik_3071;
    // this.umur_3071 = umur_3071;
    // this.alamat_3071 = alamat_3071;
  }
}
