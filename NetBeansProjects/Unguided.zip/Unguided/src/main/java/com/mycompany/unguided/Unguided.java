/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.unguided;

/**
 *
 * @author badnoby
 */
public class Unguided {

    public static void main(String[] args) {
        Limas P = new Limas (1,2,5,2,2,3,2,7);
        
        P.tampil();
    }
}
